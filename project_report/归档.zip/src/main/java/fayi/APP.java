package fayi;

import fayi.config.Config;
import fayi.config.DefaultParam;
import fayi.utils.SetAException;
import fayi.xml.Xml;
import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import java.io.IOException;


@Slf4j
@SpringBootApplication
public class APP implements CommandLineRunner {
    
    public static void main(String[] args) {
        SpringApplication.run(APP.class, args);
    }

    @Override
    public void run(String... args) throws SetAException, IOException {

        if(args.length < 1){
            System.err.println("需要指定xml文件路径，xml 以 _result.xml 结尾");
            System.exit(1);
        }
        String xmlPath = args[0];

        System.setProperty("file.encoding", "UTF-8");
        log.info(System.getProperty("os.name"));

        log.info(String.valueOf(DefaultParam.STUTTER_MAX_PROPORTION));

        System.setProperty("test.artifactId", "setB");
        Config config = Config.getInstance();

        System.out.println(config.getArtifact());
        Jiaozhun jiaozhun = new Jiaozhun();
        jiaozhun.test(xmlPath);

        log.info("Finished, time used ");
    }
}
