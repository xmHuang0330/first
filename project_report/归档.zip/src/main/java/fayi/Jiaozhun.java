package fayi;

import fayi.config.Config;
import fayi.config.Enum.Gender;
import fayi.config.Enum.Panel;
import fayi.config.Param;
import fayi.tableObject.FormulaString;
import fayi.tableObject.StrInfo;
import fayi.tableObject.StrLocusInfo;
import fayi.utils.ExcelUtils;
import fayi.utils.FileUtils;
import fayi.utils.SetAException;
import fayi.utils.Utils;
import fayi.xml.Objects.BasicInfo;
import fayi.xml.Xml;
import lombok.extern.slf4j.Slf4j;
import org.apache.poi.ss.usermodel.FormulaEvaluator;
import org.apache.poi.xssf.usermodel.*;
import fayi.tableObject.SampleInfo;
import fayi.xml.Objects.Sample;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.net.URLDecoder;
import java.nio.charset.StandardCharsets;
import java.util.*;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

import static fayi.config.Enum.Panel.yarn;

@Slf4j
public class Jiaozhun {


    static Param param;

    // 未达上传标准
    static ArrayList<String> uploadStandardFiltered = new ArrayList<>();
    static int yCELimit = 35;
    static int autoCELimit = 29;
    static HashMap<String, Integer> ascoremap = new HashMap<>();
    static HashMap<String, Integer> yscoremap = new HashMap<>();

    static List<String> autoLocusOrder;

//    static List<String> exclude_chip = Arrays.asList("V350015887",
//            "V350015941",
//            "V350012399",
//            "V350011880",
//            "V350015937",
//            "V350015937",
//            "V350015989",
//            "V350015936",
//            "V350039938",
//            "V350039973");
//    static List<String> coreY = Arrays.asList("DYS19", "DYS385a/b", "DYS389I", "DYS389II", "DYS390", "DYS391", "DYS392", "DYS393", "DYS437", "DYS438", "DYS439", "DYS448", "DYS456", "DYS458", "DYS635", "Y-GATA-H4", "DYS481", "DYS533", "DYS576");
//    static List<String> coreA = Arrays.asList("D18S51", "D21S11", "D3S1358", "FGA", "D8S1179", "vWA", "CSF1PO", "D16S539", "D7S820", "D13S317", "D5S818", "D2S1338", "D19S433", "TH01", "TPOX", "D12S391", "D1S1656", "D2S441", "D22S1045", "D10S1248");

    private static int getAutoByChip(String chip){
        return ascoremap.getOrDefault(chip, autoCELimit);
    }
    private static int getYByChip(String chip){
        return yscoremap.getOrDefault(chip, yCELimit);
    }

    public void test(String xmlDir) throws IOException,SetAException {
        boolean merge = true;
        System.out.println("start.");

        Config config = Config.getInstance();
        config.setYSTD("BGI_Y");
        config.setWorker(Byte.parseByte("30"));
        param = config.getParam();
        autoLocusOrder = param.locusOrder.get("MR36A").stream().filter(s -> !Arrays.asList("Y-indel", "DYS391", "Amelogenin", "D14S608", "SE33").contains(s)).collect(Collectors.toList());

        File[] files = new File(xmlDir).listFiles(pathname -> pathname.getName().endsWith("_result.xml")
//                &&  pathname.getName().contains("87798")
        );
        Xml xml = new Xml();

        HashMap<String, SampleInfo> distinct = new HashMap<>();
        HashMap<String, ArrayList<SampleInfo>> duplicate = new HashMap<>();

        HashMap<String, ArrayList<SampleInfo>> projectSamples = new HashMap<>();
        ArrayList<SampleInfo> control = new ArrayList<>();
        ArrayList<String> autoSamples = new ArrayList<>();

        int count = 0;
        for (File file : files != null ? files : new File[0]) {
            for(Sample sample :xml.xmlToData(file.getAbsolutePath()).samples){
                try{
                    sample.basicInfo.name = sample.basicInfo.name.toUpperCase(Locale.ROOT);

                }catch (NullPointerException e){
                    System.out.println(sample.basicInfo);
                    System.out.println(file.getName());

                }

                SampleInfo sampleInfo = xml.sampleToSampleInfo( sample );
                //过滤特定项目
                sampleInfo.getBasicInfo().setChip(sample.getBasicInfo().lane.substring(0,10));
                if (testIsControl(sampleInfo)) {
                    control.add(sampleInfo);
                    continue;
                }
                alleleCount(sampleInfo);
                //分项目
                if (!projectSamples.containsKey(sample.basicInfo.project)) {
                    projectSamples.put(sample.basicInfo.project,new ArrayList<>());
                }
                projectSamples.get(sample.basicInfo.project).add(sampleInfo);

                if(!distinct.containsKey(sample.basicInfo.name)){
                    distinct.put(sample.basicInfo.name,sampleInfo);

                }else{
                    if(!merge){
                        sampleInfo.getBasicInfo().name = sample.basicInfo.name+"_"+sample.basicInfo.lane+"_"+sample.basicInfo.id;
                        distinct.put(sample.basicInfo.name+"_"+sample.basicInfo.lane+"_"+sample.basicInfo.id, sampleInfo);
                        continue;
                    }
                    if(!duplicate.containsKey(sample.basicInfo.name)){
                        duplicate.put(sample.basicInfo.name,new ArrayList<>());
                        duplicate.get(sample.basicInfo.name).add(distinct.get(sample.basicInfo.name));
                    }
                    duplicate.get(sample.basicInfo.name).add(sampleInfo);

                    if(distinct.get(sample.basicInfo.name).getCalResult().isQualityPass()){
                        if(sampleInfo.getCalResult().isQualityPass()){
                            if(Math.abs(distinct.get(sample.basicInfo.name).getCalResult().strAvg - sample.getCalResult().strAvg) < 30 ){
                                if(distinct.get(sample.basicInfo.name).getCalResult().getATyped() < sample.getCalResult().getATyped()){
                                    distinct.put(sample.basicInfo.name,sampleInfo);
                                }
                            }else{
                                if(distinct.get(sample.basicInfo.name).getCalResult().getATyped() < sample.getCalResult().getATyped()){
                                    distinct.put(sample.basicInfo.name,sampleInfo);
                                }
                            }
                        }
                    } else {
                        if (sampleInfo.getCalResult().isQualityPass()) {
                            distinct.put(sample.basicInfo.name, sampleInfo);
                        }
                    }
                }
            }
            System.out.println(distinct.size());
        }

        System.out.println(count+"个已经上传");

        mixLevel(distinct);
        for (String project : projectSamples.keySet()) {

            markFilter(projectSamples.get(project));

            FileInputStream fileInputStream = new FileInputStream(config.getProjectPath() + "/projectCalTemplate.xlsx");
            XSSFWorkbook wb = new XSSFWorkbook(fileInputStream);
            fileInputStream.close();
            CETypedStatistic(project, distinct, wb);

            depthCoverage(projectSamples.get(project), wb);
            fillControlTable( control, wb );
            locusMutedTimes( project, distinct, wb );

            failedSamples( project, distinct, wb );
            projectAviliableSample( project, distinct, wb);
            autoAviliableSamples(project, distinct, wb, autoSamples);
            genoType( project, distinct, wb );
            tabletExam( project, distinct, wb);
            sameResultFind(project, distinct, wb, autoSamples);

            FormulaEvaluator formulaEvaluator = wb.getCreationHelper().createFormulaEvaluator();
            formulaEvaluator.evaluate(wb.getSheet("位点未出峰").getRow(1).getCell(5));
            FileOutputStream fileOutputStream = new FileOutputStream(xmlDir + "/summary_" + project + ".xlsx");
            wb.write(fileOutputStream);
            fileOutputStream.close();
            wb.close();
        }

        System.out.println(uploadStandardFiltered.size());
    }
    public void markFilter(ArrayList<SampleInfo> sampleInfos) {
        for (SampleInfo sampleInfo : sampleInfos) {
            if (sampleInfo.getCalResult().strAvg > 200 && sampleInfo.getChrACCount().get("Auto") <= 30 && sampleInfo.getChrACCount().get("Y") <= 50) {
                if(Config.getInstance().getPanel().equals( yarn )){
                    int count = 0;
                    for (String locus : param.YStrLocusOrder) {
                        if (sampleInfo.getStrLocusInfo().getOrDefault(locus,new StrLocusInfo()).getAllele().size() > 0) {
                            count++;
                        }
                    }
                    if(count < 20) {
                        continue;
                    }
                }
                sampleInfo.getCalResult().setQualityPass(true);
            }
        }
    }
    private void tabletExam(String project, HashMap<String,SampleInfo> distinct, XSSFWorkbook wb){
        Map<String, List<SampleInfo>> collect = distinct.values().stream().filter(sampleInfo -> project.equals(sampleInfo.getBasicInfo().project) && !sampleInfo.getBasicInfo().name.equals("")).collect(Collectors.groupingBy(si -> si.getBasicInfo().tablet == null?"":si.getBasicInfo().tablet));
        HashMap<String, Integer> well_count = new HashMap<>();
//        distinct.values().stream()
//                .filter(sampleInfo -> sampleInfo.getCalResult().getPP21Count()>=30)
//                .forEach(sampleInfo -> well_count.put(sampleInfo.getBasicInfo().well,
//                        well_count.containsKey(sampleInfo.getBasicInfo().well)?1:
//                                well_count.get(sampleInfo.getBasicInfo().well)));
        
        ArrayList<ArrayList<Object>> data = new ArrayList<>();
        for(List<SampleInfo> sampleInfos: collect.values()){
            sampleInfos.sort((o1, o2) -> {
                try {
                    int a = Integer.parseInt(o1.getBasicInfo().well.substring(0, o1.getBasicInfo().well.length() - 1));
                    int b = Integer.parseInt(o2.getBasicInfo().well.substring(0, o2.getBasicInfo().well.length() - 1));
                    return a==b?o1.getBasicInfo().well.charAt(o1.getBasicInfo().well.length()-1) - o2.getBasicInfo().well.charAt(o2.getBasicInfo().well.length()-1):a-b;
                }catch (StringIndexOutOfBoundsException e){
                    return 0;
                }
            });
            SampleInfo sampleInfo = sampleInfos.get(0);
            data.add(new ArrayList<>(Arrays.asList(sampleInfo.getBasicInfo().project,
                    sampleInfo.getBasicInfo().chip,
                    sampleInfo.getBasicInfo().tablet,
                    sampleInfo.getBasicInfo().well,
                    sampleInfo.getBasicInfo().name)));
            SampleInfo sampleInfo1 = sampleInfos.get(sampleInfos.size() - 1);
            data.add(new ArrayList<>(Arrays.asList(sampleInfo1.getBasicInfo().project,
                    sampleInfo1.getBasicInfo().chip,
                    sampleInfo1.getBasicInfo().tablet,
                    sampleInfo1.getBasicInfo().well,
                    sampleInfo1.getBasicInfo().name)));
        }
        ExcelUtils.writeData(wb, "一代校准", "", 1, 0, data);
    }

    private void sameResultFind(String project, HashMap<String,SampleInfo> distinct, XSSFWorkbook wb, List<String> ySamples) {
        List<SampleInfo> samples = distinct.values().stream().filter(sampleInfo -> {
            if (!project.equals(sampleInfo.getBasicInfo().project)) return false;
            if (ySamples.contains(sampleInfo.getBasicInfo().name)) return false;
            return sampleInfo.getCalResult().getPP21Count() >= getAutoByChip(sampleInfo.getBasicInfo().chip);
        }).collect(Collectors.toList());
        long startTime=System.currentTimeMillis();
        HashSet<String> targetDone = new HashSet<>();

//        ExecutorService executorService = Executors.newFixedThreadPool(Config.getInstance().getWorker());
//        AtomicInteger count = new AtomicInteger();
        HashMap<String, HashSet<String>> foundResult = new HashMap<>();
        for(SampleInfo sampleInfo:samples){
            targetDone.add(sampleInfo.getBasicInfo().name);
            for(SampleInfo target:samples){

                if(targetDone.contains(target.getBasicInfo().name)) continue;
                int sum = 0;
                boolean mark = true;
                int available_locus = 0;
                for(String locus:Config.getInstance().getParam().locusOrder.get("MR36A")){
                    ArrayList<StrInfo> sourceAllele = sampleInfo.getStrLocusInfo().getOrDefault(locus, new StrLocusInfo()).getAllele();
                    ArrayList<StrInfo> targetAllele = target.getStrLocusInfo().getOrDefault(locus, new StrLocusInfo()).getAllele();
                    if(sourceAllele.size()>0 && targetAllele.size()>0){
                        available_locus += 1;
                        if(!sourceAllele.containsAll(targetAllele)){
                            sum += 1;
                        }
                    }
                    if (sum > 1) {
                        mark = false;
                        break;
                    }
                }
                if(mark && available_locus > 10){
                    targetDone.add(target.getBasicInfo().name);
                    if(!foundResult.containsKey(sampleInfo.getBasicInfo().name)){
                        foundResult.put(sampleInfo.getBasicInfo().name,new HashSet<>());
//                        count.getAndIncrement();
                    }
                    foundResult.get(sampleInfo.getBasicInfo().name).add(target.getBasicInfo().name);
                }
            }
        }
//        Utils.poolExecuterWaiter(executorService, " looking for samples contains same data ", count);

        long endTime=System.currentTimeMillis();
        System.out.printf("checking conflict %.2fs used...%n", (endTime - startTime) / 1000.0);
        ArrayList<ArrayList<Object>> data = new ArrayList<>();
//        ArrayList<Object> header = new ArrayList<>();
//        header.add("name");
//        header.add("chip");
//        header.add("index");
//        header.add("tablet");
//        header.addAll( param.StrLocusOrder );
//        data.add( header );
        for(String source:foundResult.keySet()){

            foundResult.get(source).add(source);
            System.out.println(source +" | "+ distinct.containsKey(source));
            Map<String, Long> collect = foundResult.get(source).stream().map(distinct::get).map(SampleInfo::getBasicInfo).map(BasicInfo::getTablet).collect(Collectors.groupingBy(Function.identity(), Collectors.counting()));
            for(String target:foundResult.get(source)){
                SampleInfo targetSample = distinct.get(target);
                ArrayList<Object> targetValues = new ArrayList<>();
                targetValues.add( targetSample.getBasicInfo().name );
                targetValues.add( targetSample.getBasicInfo().lane );
                targetValues.add( targetSample.getBasicInfo().id );
                XSSFRichTextString xssfRichTextString = new XSSFRichTextString();
                xssfRichTextString.append(targetSample.getBasicInfo().tablet, Utils.createFont("blue"));
                targetValues.add( collect.get(targetSample.getBasicInfo().tablet) > 1?xssfRichTextString:targetSample.getBasicInfo().tablet );
                targetValues.add( targetSample.getBasicInfo().well);
                for(String locus: param.StrLocusOrder){
                    String alleleNameAsString = targetSample.getStrLocusInfo().getOrDefault( locus, new StrLocusInfo() ).getAlleleNameAsString( true, false );
                    targetValues.add( alleleNameAsString );
                }
                data.add( targetValues );
            }
        }
        ExcelUtils.writeData( wb , "分型一致样本", "conflict",1, 0,data,false);
    }

    private void autoAviliableSamples(String project, HashMap<String, SampleInfo> distinct, XSSFWorkbook wb, List<String> autoSamples) {
        ArrayList<ArrayList<Object>> data = new ArrayList<>();
        ArrayList<Object> header = new ArrayList<>();
        header.add("name");
        header.add("tablet");
        header.add("lane");
        header.add("index");
        header.addAll( param.StrLocusOrder );
        header.add("Amelogenin");
        data.add( header );
        for(SampleInfo sampleInfo:distinct.values()){
            if(autoSamples.contains( sampleInfo.getBasicInfo().name )){
                continue;
            }
            if(!project.equals( sampleInfo.getBasicInfo().project )){
                continue;
            }
            if(!sampleInfo.getCalResult().isQualityPass()){
                continue;
            }
            if(sampleInfo.getCalResult().getPP21Count() < getAutoByChip(sampleInfo.getBasicInfo().chip)){
                continue;
            }
            if( !Gender.female.equals(sampleInfo.getBasicInfo().gender) && sampleInfo.getCalResult().getY41Count() < getYByChip(sampleInfo.getBasicInfo().chip)){
                continue;
            }
            ArrayList<Object> values = new ArrayList<>();
            values.add( sampleInfo.getBasicInfo().name );
            values.add(sampleInfo.getBasicInfo().tablet);
            values.add(sampleInfo.getBasicInfo().lane);
            values.add(sampleInfo.getBasicInfo().id);
            for(String locus: param.StrLocusOrder){
                String alleleNameAsString = sampleInfo.getStrLocusInfo().getOrDefault( locus, new StrLocusInfo() ).getAlleleNameAsString( true, false );
                values.add( alleleNameAsString );
            }
            values.add( sampleInfo.getStrLocusInfo().getOrDefault( "Amelogenin", new StrLocusInfo() ).getAlleleNameAsString( true, false ) );
            data.add( values );
        }
        ExcelUtils.writeData( wb , "available", "",0, 0,data);
    }
    private static ArrayList<String> readSamples(String file) {
        FileUtils fileUtils = new FileUtils(file);
        String line;
        ArrayList<String> samples = new ArrayList<>();
        while ((line = fileUtils.readLine()) != null) {
            line = line.trim();
            samples.add( line );
        }
        return samples;
    }

    private static void mixLevel(HashMap<String, SampleInfo> distinct) {
        for (SampleInfo sampleInfo : distinct.values()) {
            float sum = 0;
            float count = 0;
            for (String locus : Config.getInstance().getParam().AutoStrLocusOrder) {
                float genodp = 0;
                float nodp = 0;
                for (StrInfo strInfo : sampleInfo.getStrData().getOrDefault(locus, new ArrayList<>())) {
                    if (strInfo.getTyped()) {
                        genodp += strInfo.getReads();
                    } else if (!strInfo.getIsStutter() && !strInfo.getIsNGStutter()) {
                        nodp += strInfo.getReads();
                    }
                }
                if (genodp != 0) {
                    count++;
                    sum += genodp / (genodp + nodp);
                }
            }

            sampleInfo.getCalResult().setMixLevel(sum / count);
        }
    }


    private static void alleleCount(SampleInfo sampleInfo) {
        int auto = 0;
        int y = 0;
        for (String locus : Param.getInstance().StrLocusOrder) {
            int count = 0;
            for (StrInfo strInfo : sampleInfo.getStrData().getOrDefault(locus, new ArrayList<>())) {
                if (!strInfo.getIsStutter() && !strInfo.getIsNGStutter() && !strInfo.getTyped()) {
                    if(strInfo.getReads()/sampleInfo.getStrLocusInfo().getOrDefault(locus, new StrLocusInfo()).getTotalDepth() > 0.3) {
                        count++;
                    }
                }
            }
            if (count > 0) {
                if (param.AutoStrLocusOrder.contains(locus)) {
                    auto++;
                } else if (param.YStrLocusOrder.contains(locus)) {
                    y++;
                }
            }
        }
        sampleInfo.getChrACCount().put("Auto", auto);
        sampleInfo.getChrACCount().put("Y", y);

    }

    private static void failedSamples(String project, HashMap<String, SampleInfo> distinct, XSSFWorkbook wb) {
        ArrayList<SampleInfo> failed = new ArrayList<>();
        for (SampleInfo sampleInfo : distinct.values()) {
            if (!project.equals(sampleInfo.getBasicInfo().project)) {
                continue;
            }
            if (!sampleInfo.getCalResult().isQualityPass() ) {
                failed.add(sampleInfo);
                continue;
            }
            if (testIsControl(sampleInfo)) {
                continue;
            }
//            int ystrSum = 0;
//            for(String locus:param.YStrLocusOrder) {
//                ystrSum += sampleInfo.getStrLocusInfo().get(locus).getTotalDepth();
//            }
//            int autoSum = 0;
//            for(String locus:param.AutoStrLocusOrder){
//                autoSum += sampleInfo.getStrLocusInfo().get(locus).getTotalDepth();
//            }
//            if((ystrSum/(float)param.YStrLocusOrder.size())/(autoSum/(float)param.AutoStrLocusOrder.size()) < 0.1){
//                sampleInfo.getBasicInfo().gender = Gender.female;
//            }

            if (Panel.setB.equals( Config.getInstance().getPanel() )) {
                if (Gender.male.equals( sampleInfo.getBasicInfo().getGender() )) {
                    if (sampleInfo.getCalResult().getY41Count() < getYByChip(sampleInfo.getBasicInfo().chip)) {
                        failed.add( sampleInfo );
                        continue;
                    }
                }
                if (sampleInfo.getCalResult().getPP21Count() < getAutoByChip(sampleInfo.getBasicInfo().chip)) {
                    failed.add( sampleInfo );
                    continue;
                }
            } else if (Panel.setA.equals( Config.getInstance().getPanel() )) {
                if ("Fail".equals( sampleInfo.getCalResult().singleSource )) {
                    continue;
                }
            }else if(Panel.yarn.equals(Config.getInstance().getPanel())){
                if (sampleInfo.getCalResult().getY41Count() < getYByChip(sampleInfo.getBasicInfo().chip)) {
                    failed.add( sampleInfo );
                    continue;
                }
            }

            if(sampleInfo.getCalResult().getY41Count() >= getYByChip(sampleInfo.getBasicInfo().chip) && sampleInfo.getCalResult().getPP21Count() >= getAutoByChip(sampleInfo.getBasicInfo().chip))
                uploadStandardFiltered.add(sampleInfo.getBasicInfo().name);
        }

        ArrayList<ArrayList<Object>> controlData = new ArrayList<>();
        for(SampleInfo sampleInfo:failed){
            ArrayList<Object> values = new ArrayList<>();
            values.add(sampleInfo.getBasicInfo().lane);
            values.add(sampleInfo.getBasicInfo().id);
            values.add(sampleInfo.getBasicInfo().tablet);
            values.add(sampleInfo.getBasicInfo().well);
            values.add(sampleInfo.getBasicInfo().gender);
            values.add(sampleInfo.getBasicInfo().type);
            values.add(sampleInfo.getBasicInfo().project);
            values.add(sampleInfo.getBasicInfo().name);
            values.add(sampleInfo.getCalResult().availableDepth);
            values.add(sampleInfo.getCalResult().fqReads);
            values.add(sampleInfo.getCalResult().availableDepth / sampleInfo.getCalResult().fqReads);
            values.add(sampleInfo.getCalResult().getInterlocusBalance());
            values.add(sampleInfo.getCalResult().getSingleSource());
            values.add(sampleInfo.getCalResult().getMixLevel());
//            alleleCount(sampleInfo);
            values.add(sampleInfo.getChrACCount().get("Auto"));
            values.add(sampleInfo.getChrACCount().get("Y"));
            values.add(sampleInfo.getCalResult().getHighStutter());
            values.add(sampleInfo.getCalResult().getPP21Count());
            values.add(sampleInfo.getCalResult().getY41Count());
            values.add(sampleInfo.getCalResult().getATyped());
            values.add(sampleInfo.getCalResult().getYTyped());
            values.add(sampleInfo.getCalResult().strAvg);
            values.add(sampleInfo.getCalResult().strSTD);
            values.add(sampleInfo.getCalResult().getYProportion());
            values.add(sampleInfo.getCalResult().isQualityPass());
            for (String locus : param.StrLocusOrder) {
                values.add(sampleInfo.getStrLocusInfo().getOrDefault(locus, new StrLocusInfo()).getTotalDepth());
            }
            controlData.add(values);
        }
        ArrayList<Object> header = new ArrayList<>(Arrays.asList("chip_lane", "index", "tablet", "well", "gender", "type", "project", "name", "aviliableDepth", "fastqReads", "readsProportion"
                , "位点深度STD风险", "污染风险", "混合指数", "常ac数", "Yac数","stutter高占比数", "MR36A出峰数", "Y41出峰数", "常出峰数", "Y出峰数", "STR深度均值", "str深度标准差","Y深度占比", "可输出"));
        header.addAll(param.StrLocusOrder);
        controlData.add(0, header);
        ExcelUtils.writeData(wb, "未达上传标准样本", "", 0, 0, controlData,false);

    }

    private static HashSet<String> getLanes(HashMap<String, SampleInfo> distinct) {
        HashSet<String> lanes = new HashSet<>();
        for (SampleInfo sampleInfo : distinct.values()) {
            lanes.add(sampleInfo.getBasicInfo().lane);
        }
        return lanes;
    }

    private static void productionCal(XSSFWorkbook sheets, Set<String> projects, HashMap<String, SampleInfo> distinct) {
        ArrayList<ArrayList<Object>> total = new ArrayList<>();
        ArrayList<Object> header = new ArrayList<>(Arrays.asList("项目", "lane", "总样本数", "达到输出标准样本数", "可上传样本数", "常一代"+autoCELimit, "Y一代"+yCELimit));
        total.add(header);
        HashSet<String> lanes = getLanes(distinct);
        for (String project : projects) {
            for (String lane : lanes) {
                int projectSampleCount = 0;
                int passQCCount = 0;
                int uploadCount = 0;
                int aboveY35 = 0;
                int aboveY28 = 0;
                int aboveHXBJ21 = 0;
                for (String sampleName : distinct.keySet()) {
                    if (!project.equals(distinct.get(sampleName).getBasicInfo().project) || !lane.equals(distinct.get(sampleName).getBasicInfo().lane)) {
                        continue;
                    }
                    if (testIsControl(distinct.get(sampleName))) {
                        continue;
                    }
                    projectSampleCount++;
                    if (distinct.get(sampleName).getCalResult().isQualityPass()) {
                        passQCCount++;
                        if (uploadStandardFiltered.contains(sampleName)) {
                            uploadCount++;
                        }
                    }
                    if (distinct.get(sampleName).getCalResult().getY41Count() >= getYByChip(distinct.get(sampleName).getBasicInfo().chip)) {
                        aboveY35++;
                    }
                    if (distinct.get(sampleName).getCalResult().getPP21Count() >= getAutoByChip(distinct.get(sampleName).getBasicInfo().chip)) {
                        aboveHXBJ21++;
                    }
                }
                total.add(new ArrayList<>(Arrays.asList(project, lane, projectSampleCount, passQCCount, uploadCount, aboveHXBJ21, aboveY35, aboveY28)));
            }
        }

        ExcelUtils.writeData(sheets, "sheet1", "", 0, 0, total);

    }

    private static boolean testIsControl(SampleInfo sampleInfo){
        for(String type:new String[]{"h2o","阴性","阳性","water","ladder"}) {
            if (sampleInfo.getBasicInfo().type.toLowerCase().contains(type)){
                return true;
            }
        }
        return false;
    }

    private static void locusMutedTimes(String project, HashMap<String,SampleInfo> sampleInfos, XSSFWorkbook wb) {
        HashMap<String, HashMap<String, Integer>> laneCal = new HashMap<>();
//        ArrayList<String> locuses = new ArrayList<>();
//        locuses.addAll(coreA);
//        locuses.addAll(coreY);
        List<SampleInfo> projectSamples = sampleInfos.values().stream().filter(sampleInfo -> project.equals(sampleInfo.getBasicInfo().project)).collect(Collectors.toList());
        for (String locus : Config.getInstance().getParam().StrLocusOrder) {
            for (SampleInfo sampleInfo : projectSamples) {
                if (! laneCal.containsKey( sampleInfo.getBasicInfo().lane )) {
                    laneCal.put( sampleInfo.getBasicInfo().lane, new HashMap<>() );
                }
                if (! laneCal.get( sampleInfo.getBasicInfo().lane ).containsKey( locus )) {
                    laneCal.get( sampleInfo.getBasicInfo().lane ).put( locus, 0 );
                }
                laneCal.get( sampleInfo.getBasicInfo().lane ).put( locus, laneCal.get( sampleInfo.getBasicInfo().lane ).get( locus ) + (sampleInfo.getStrLocusInfo().getOrDefault( locus, new StrLocusInfo() ).getAllele().size() > 0 ? 0 : 1) );
            }
        }
        ArrayList<ArrayList<Object>> data = new ArrayList<>();
        for (String locus : Config.getInstance().getParam().StrLocusOrder) {
            ArrayList<Object> values = new ArrayList<>();
            values.add( locus );
            int total = 0;
            for (String lane : laneCal.keySet()) {
                total += laneCal.get( lane ).get( locus );
                values.add( laneCal.get( lane ).get( locus ) );
            }
            values.add( total );
            data.add( values );
        }
        ExcelUtils.writeData(wb,"位点未出峰","位点未出峰",3,0,data);
        HashMap<String,Integer> laneCount = new HashMap<>();
        for(SampleInfo sampleInfo : projectSamples) {
            if(!laneCount.containsKey(sampleInfo.getBasicInfo().lane)){
                laneCount.put(sampleInfo.getBasicInfo().lane,0);
            }
            laneCount.put(sampleInfo.getBasicInfo().lane,laneCount.get(sampleInfo.getBasicInfo().lane)+1);
        }
        data = new ArrayList<>();
        ArrayList<Object> count = new ArrayList<>(laneCount.values());
        count.add(new FormulaString("","SUM("+ExcelUtils.index2ColName(1)+"2:"+ExcelUtils.index2ColName(1+count.size()-1)+"2)"));
        data.add(count);
        ArrayList<Object> header = new ArrayList<>(laneCount.keySet());
        header.add("Total");
        data.add(header);

        ExcelUtils.writeData(wb,"位点未出峰","",1,1,data);
    }

    private static void fillCorrectionTable(HashMap<String, ArrayList<SampleInfo>> duplicate, XSSFWorkbook wb) {
        ArrayList<ArrayList<Object>> data = new ArrayList<>();

        ArrayList<Object> header = new ArrayList<>();
        header.addAll(Arrays.asList("chip_lane","index","name","tablet","well","project","diffCount"));
        header.addAll(param.StrLocusOrder);
        data.add(header);
        for(String key:duplicate.keySet()){
            HashMap<String, int[]> diffCount = new HashMap<>();
            for(String locus: param.StrLocusOrder){
                List<String> genotype = duplicate.get(key).stream()
                        .map(sampleInfo -> sampleInfo.getStrLocusInfo().get(locus).getAlleleNameAsString(true, false))
                        .filter(str-> !"".equals(str))
                        .distinct()
                        .collect(Collectors.toList());
                List<String> seqType = duplicate.get(key).stream()
                        .map(sampleInfo -> sampleInfo.getStrLocusInfo().get(locus).getSequenceAsString())
                        .filter(str-> !"".equals(str))
                        .distinct()
                        .collect(Collectors.toList());
                diffCount.put(locus,new int[]{genotype.size(), seqType.size()});
            }
            long alleleDiffCount = diffCount.values().stream().filter(ints -> ints[0] > 1).count();
            boolean write = alleleDiffCount > 3;
//            if(!write){
//                continue;
//            }
            for(SampleInfo sampleInfo: duplicate.get(key)){
                ArrayList<Object> values = new ArrayList<>();
                values.add(sampleInfo.getBasicInfo().lane);
                values.add(sampleInfo.getBasicInfo().id);
                values.add(sampleInfo.getBasicInfo().name);
                values.add(sampleInfo.getBasicInfo().tablet);
                values.add(sampleInfo.getBasicInfo().well);
                values.add(sampleInfo.getBasicInfo().project);
                values.add(alleleDiffCount);

                for(String locus: param.StrLocusOrder){
                    String alleleNameAsString = sampleInfo.getStrLocusInfo().get(locus).getAlleleNameAsString(false, false);
                    if(diffCount.get(locus)[0] > 1) {
                        XSSFRichTextString xssfRichTextString = new XSSFRichTextString(alleleNameAsString);
                        xssfRichTextString.applyFont(Utils.createFont("red"));
                        values.add(xssfRichTextString);
                    }else {
                        values.add(alleleNameAsString);
                    }
                }
                data.add(values);

            }
//            for (int i = 0; i < duplicate.get(key).size(); i++) {
//                SampleInfo sampleInfo = duplicate.get(key).get(i);
//                ArrayList<Object> values = new ArrayList<>();
//                values.add(sampleInfo.getBasicInfo().lane);
//                values.add(sampleInfo.getBasicInfo().id);
//                values.add(sampleInfo.getBasicInfo().name);
//                values.add(sampleInfo.getBasicInfo().tablet);
//                values.add(sampleInfo.getBasicInfo().well);
//                values.add(sampleInfo.getBasicInfo().project);
//                int count = 0;
//                for (int j = 0; j < param.StrLocusOrder.size(); j++) {
//                    StrLocusInfo strLocusInfo = sampleInfo.getStrLocusInfo().get(param.StrLocusOrder.get(j));
//                    if (strLocusInfo == null || "".equals(strLocusInfo.getAlleleNameAsString(false, false))) {
//                        values.add("");
//                        continue;
//                    }
//                    StrLocusInfo strLocusInfo1 = new StrLocusInfo();
//                    for (int k = 0; k < duplicate.get(key).size(); k++) {
//                        if (duplicate.get(key).get(k).getStrLocusInfo().get(param.StrLocusOrder.get(j)) != null) {
//                            if (!"".equals(duplicate.get(key).get(k).getStrLocusInfo().get(param.StrLocusOrder.get(j)).getAlleleNameAsString(false, false))) {
//                                strLocusInfo1 = duplicate.get(key).get(k).getStrLocusInfo().get(param.StrLocusOrder.get(j));
//                            }
//                        }
//                    }
//
//
//                    if (!strLocusInfo.getAlleleNameAsString(false, false).equals(strLocusInfo1.getAlleleNameAsString(false, false))) {
//                        XSSFRichTextString xssfRichTextString = new XSSFRichTextString(strLocusInfo.getAlleleNameAsString(false, false));
//                        xssfRichTextString.applyFont(Utils.createFont("red"));
//                        values.add(xssfRichTextString);
//                        count += 1;
//                    } else {
//                        ArrayList<StrInfo> allele = strLocusInfo.getAllele();
//                        ArrayList<StrInfo> allele1 = strLocusInfo1.getAllele();
////                        if(allele.size()!=allele1.size()){
////                            System.out.println();
////                        }
//                        if (allele1.size() > 1 && allele1.get(0).getAlleleName().equals(allele1.get(1).getAlleleName())) {
//
//                            allele.sort(Comparator.comparing(o -> o.getRepeatSequence().replaceAll(" ", "")));
//                            allele1.sort(Comparator.comparing(o -> o.getRepeatSequence().replaceAll(" ", "")));
//                        }
//                        XSSFRichTextString xssfRichTextString = new XSSFRichTextString();
//                        for (int k = 0; k < Math.min(allele.size(),allele1.size()); k++) {
//                            if (null != xssfRichTextString.getString() && !"".equals(xssfRichTextString.getString())) {
//                                xssfRichTextString.append(",");
//                            }
//                            StrInfo strInfo = allele.get(k);
//                            StrInfo strInfo1 = allele1.get(k);
//                            if (strInfo.getFlanking().size() > 0 && strInfo1.getFlanking().size() > 1) {
//                                if (!strInfo.getFlanking().get(0).equals(strInfo1.getFlanking().get(0)))
//                                    xssfRichTextString.append(strInfo.getAlleleName(), Utils.createFont("yellow"));
//                            } else if (!strInfo.getRepeatSequence().replaceAll(" ", "").equals(strInfo1.getRepeatSequence().replaceAll(" ", ""))) {
//                                xssfRichTextString.append(strInfo.getAlleleName(), Utils.createFont("blue"));
//                            } else {
//                                xssfRichTextString.append(strInfo.getAlleleName());
//                            }
//                        }
//                        if (xssfRichTextString.hasFormatting()) values.add(xssfRichTextString);
//                        else values.add(strLocusInfo.getAlleleNameAsString(false, false));
//                    }
//                }
//                if(count > 3) {
//                    data.add(values);
//                }
//            }

            data.add(new ArrayList<>());
        }
        ExcelUtils.writeData(wb,"校准一致性","",0,0,data);

    }

    private static void fillControlTable(ArrayList<SampleInfo> control, XSSFWorkbook wb){
        control.sort(Comparator.comparing(o -> o.getBasicInfo().tablet == null?"":o.getBasicInfo().tablet));
        ArrayList<ArrayList<Object>> controlData = new ArrayList<>();
        for(SampleInfo sampleInfo:control){
            ArrayList<Object> values = new ArrayList<>();
            values.add(sampleInfo.getBasicInfo().lane);
            values.add(sampleInfo.getBasicInfo().id);
            values.add(sampleInfo.getBasicInfo().tablet);
            values.add(sampleInfo.getBasicInfo().gender);
            values.add(sampleInfo.getBasicInfo().type);
            values.add(sampleInfo.getBasicInfo().project);
            values.add(sampleInfo.getBasicInfo().name);
            values.add(sampleInfo.getCalResult().availableDepth);
            values.add(sampleInfo.getCalResult().fqReads);
            values.add(sampleInfo.getCalResult().availableDepth / sampleInfo.getCalResult().fqReads);
            values.add(sampleInfo.getCalResult().getInterlocusBalance());
            values.add(sampleInfo.getCalResult().getSingleSource());
            values.add(sampleInfo.getCalResult().getATyped());
            values.add(sampleInfo.getCalResult().getYTyped());
            values.add(sampleInfo.getCalResult().getStrAvg());
            values.add(sampleInfo.getCalResult().strAvg);
            values.add(sampleInfo.getLowerThan30());
            values.add(sampleInfo.getLowerThan100());
            for (String locus : param.StrLocusOrder) {
                values.add(sampleInfo.getStrLocusInfo().getOrDefault(locus, new StrLocusInfo()).getAlleleNameAsString(true,false));
            }
            controlData.add(values);
        }
        ArrayList<Object> header = new ArrayList<>(Arrays.asList("chip_lane", "index", "tablet", "gender", "type", "project", "name", "aviliableDepth", "fastqReads", "readsProportion"
                , "位点深度STD风险", "污染风险", "常出峰数", "Y出峰数", "STR深度均值", "str深度标准差", "小于30x位点数", "小于100x位点数"));
        header.addAll(param.StrLocusOrder);
        controlData.add(0, header);
        ExcelUtils.writeData(wb, "对照样本", "", 0, 0, controlData);
    }

    private static void projectAviliableSample(String project, HashMap<String, SampleInfo> samples, XSSFWorkbook wb) {
        HashMap<String, ArrayList<ArrayList<Object>>> laneSamples = new HashMap<>();

        String regex = "(V[\\d]+_L0[\\d]{1})";
        Pattern compile = Pattern.compile(regex);

        for (SampleInfo sampleInfo : samples.values()) {
            if (!project.equals(sampleInfo.getBasicInfo().project)
            || sampleInfo.getCalResult().getPP21Count()<getAutoByChip(sampleInfo.getBasicInfo().chip)
//                    || !uploadStandardFiltered.contains(sampleInfo.getBasicInfo().name)
            ) {
                continue;
            }
            BasicInfo basicInfo = sampleInfo.getBasicInfo();
            String lane = basicInfo.getLane();
            Matcher matcher = compile.matcher(basicInfo.getFastq());
            if (matcher.find()) {
                lane = matcher.group(1);
            }

            if (!laneSamples.containsKey(lane)) {
                laneSamples.put(lane, new ArrayList<>());
                laneSamples.get(lane).add(new ArrayList<>(Arrays.asList("index号", "板号", "样品编号", "项目", "性别", "类型", "panel", "备注")));
            }

            ArrayList<Object> values = new ArrayList<>();
            values.add(sampleInfo.getBasicInfo().id);
            values.add(sampleInfo.getBasicInfo().tablet);
            values.add(sampleInfo.getBasicInfo().name);
            values.add(sampleInfo.getBasicInfo().project);
            values.add(sampleInfo.getBasicInfo().gender.Description);
            values.add("");
            values.add("SETB");
            values.add(sampleInfo.getBasicInfo().well);

            laneSamples.get(lane).add(values);
        }
        for (String lane : laneSamples.keySet()) {
            ExcelUtils.writeData(wb, lane, "", 0, 0, laneSamples.get(lane));
        }
    }

    private static void depthCoverage(ArrayList<SampleInfo> sampleInfos, XSSFWorkbook wb) {
        int col = 0;
        List<String> lanes = sampleInfos.stream().map(sampleInfo -> sampleInfo.getBasicInfo().getLane()).distinct().collect(Collectors.toList());
        XSSFSheetConditionalFormatting sheet = wb.getSheet("位点平均深度").getSheetConditionalFormatting();
        for (String lane : lanes) {
            ArrayList<ArrayList<Object>> laneDepth = new ArrayList<>();
            for (String locus : param.StrLocusOrder) {
                int maleSumDepth = 0;
                int femaleSumDepth = 0;
                int uncertainSumDepth = 0;
                float maleCount = 0;
                float femaleCount = 0;
                float uncertainCount = 0;
                for (SampleInfo sampleInfo : sampleInfos) {
                    if (sampleInfo.getBasicInfo().lane.equals(lane)) {
                        if (Gender.male.equals(sampleInfo.getBasicInfo().gender)) {
                            maleSumDepth += sampleInfo.getStrLocusInfo().getOrDefault(locus, new StrLocusInfo()).getTotalDepth();
                            maleCount++;
                        } else if (Gender.female.equals(sampleInfo.getBasicInfo().gender)) {
                            femaleSumDepth += sampleInfo.getStrLocusInfo().getOrDefault(locus, new StrLocusInfo()).getTotalDepth();
                            femaleCount++;
                        } else {
                            uncertainSumDepth += sampleInfo.getStrLocusInfo().getOrDefault(locus, new StrLocusInfo()).getTotalDepth();
                            uncertainCount++;
                        }
                    }
                }
                wb.getSheet("位点平均深度").getRow(0).createCell(col).setCellValue(lane);
                laneDepth.add(new ArrayList<>(Arrays.asList(locus, maleCount == 0 ? "" : maleSumDepth / maleCount, femaleCount == 0 ? "" : femaleSumDepth / femaleCount, uncertainCount == 0 ? "" : uncertainSumDepth / uncertainCount)));
            }
            ExcelUtils.writeData(wb, "位点平均深度", "", 3, col, laneDepth);
            col += 5;
            XSSFConditionalFormattingRule conditionalFormattingColorScaleRule = sheet.createConditionalFormattingColorScaleRule();
            XSSFColorScaleFormatting colorScaleFormatting = conditionalFormattingColorScaleRule.createColorScaleFormatting();
        }
    }

    private static int locusProduction(SampleInfo sampleInfo, List<String> locusOrder, HashMap<Integer, Integer> levelCount, int locus_count){

        int validCount = 0;
        for (String locus : locusOrder) {
            if (sampleInfo.getStrLocusInfo().getOrDefault(locus, new StrLocusInfo()).getAllele().size() > 0) {
                validCount += 1;
                if (locus.endsWith("a/b")) {
                    validCount += 1;
                }
            } else {
//                System.out.println(locus);
            }
        }
        for (int i = locus_count-24; i <= locus_count; i++) {
            if (validCount == i) {
                for (int j = i; j >= locus_count-24; j--) {
                    levelCount.put(j, levelCount.getOrDefault(j, 0) + 1);
                }
                break;
            }
        }
        return validCount;

    }

    private static ArrayList<ArrayList<Object>> panelCount(List<String> locusOrder, HashMap<Integer, Integer> levelCount, float totalSamples){

        ArrayList<ArrayList<Object>> result = new ArrayList<>();
        int count = locusOrder.size() + (int) locusOrder.stream().filter(s -> s.endsWith("a/b")).count();
        for (int i = count - 24; i <= count; i++) {
            ArrayList<Object> data = new ArrayList<>();
            data.add(i);
            data.add(levelCount.getOrDefault(i, 0));
            data.add(levelCount.getOrDefault(i, 0) / (totalSamples));
            result.add(data);
        }
        return result;
    }

    private static void CETypedStatistic(String project, HashMap<String,SampleInfo> samples, XSSFWorkbook wb) throws SetAException {

        ArrayList<ArrayList<Object>> allSampleTyped = new ArrayList<>();

        float maleCount = 0;
        float totalCount = 0;
        HashMap<Integer, Integer> autoLocusCount = new HashMap<>();
        HashMap<Integer, Integer> pp21LocusCount = new HashMap<>();
        HashMap<Integer, Integer> yLocusCount = new HashMap<>();
        HashMap<Integer, Integer> y41LocusCount = new HashMap<>();
        HashMap<Integer, Integer> y41_YSUPLocusCount = new HashMap<>();
        HashMap<Integer, Integer> BGILocusCount = new HashMap<>();
        int y41_locus_count = param.locusOrder.get("Y41").size()+(int)param.locusOrder.get("Y41").stream().filter(s -> s.endsWith("a/b")).count();
        int ysup_locus_count = param.locusOrder.get("Y41_YSUP").size()+(int)param.locusOrder.get("Y41_YSUP").stream().filter(s -> s.endsWith("a/b")).count();
        int bgi_locus_count = param.locusOrder.get("BGI_Y").size()+(int)param.locusOrder.get("BGI_Y").stream().filter(s -> s.endsWith("a/b")).count();
        for(SampleInfo sampleInfo:samples.values() ) {
            if (!project.equals(sampleInfo.getBasicInfo().getProject())) {
                continue;
            }
            if (testIsControl(sampleInfo)) {
                continue;
            }
            totalCount += 1;

            int autoCount = locusProduction( sampleInfo, param.AutoStrLocusOrder, autoLocusCount,param.AutoStrLocusOrder.size() );
            int pp21Count = locusProduction( sampleInfo, autoLocusOrder, pp21LocusCount,autoLocusOrder.size() );

            sampleInfo.getCalResult().setPP21Count(pp21Count);
            int yCount = 0;
            int y41Count;
            if (Gender.male.equals(sampleInfo.getBasicInfo().gender)) {
                maleCount += 1;
                yCount = locusProduction( sampleInfo, param.YStrLocusOrder, yLocusCount, param.YStrLocusOrder.size()+4);
                int y41 = locusProduction( sampleInfo, param.locusOrder.get("Y41"), y41LocusCount,y41_locus_count );
                int sup = locusProduction( sampleInfo, param.locusOrder.get("Y41_YSUP"), y41_YSUPLocusCount,ysup_locus_count );
                int big = locusProduction( sampleInfo, param.locusOrder.get("BGI_Y"), BGILocusCount,bgi_locus_count );
                switch (Config.getInstance().getYSTD()){
                    case "Y41_YSUP":y41Count = sup;break;
                    case "BGI_Y":y41Count = big;break;
                    case "Y41":y41Count = y41;break;
                    default:throw new SetAException(1, "错误");
                }
                sampleInfo.getCalResult().setY41Count(y41Count);
            }
            ArrayList<Object> objects = new ArrayList<>();
            objects.add( sampleInfo.getName() );
            objects.add( autoCount );
            objects.add( sampleInfo.getCalResult().getPP21Count() );
            objects.add( yCount );
            objects.add( sampleInfo.getCalResult().getY41Count() );
            allSampleTyped.add( objects );
        }
        ExcelUtils.writeData(wb, "一代位点输出统计", "", 0, 7, new ArrayList<>(Collections.singletonList(new ArrayList<>(Collections.singletonList(maleCount)))));
        ExcelUtils.writeData(wb, "一代位点输出统计", "", 0, 2, new ArrayList<>(Collections.singletonList(new ArrayList<>(Collections.singletonList(totalCount)))));
//        ExcelUtils.writeData(wb, "一代位点输出统计", "", 12, 7, new ArrayList<>(Collections.singletonList(new ArrayList<>(Collections.singletonList(totalCount)))));


        ArrayList<ArrayList<Object>> all_auto = panelCount( param.AutoStrLocusOrder, autoLocusCount, totalCount );
        ArrayList<ArrayList<Object>> all_y = panelCount( param.YStrLocusOrder, yLocusCount, maleCount );
        ArrayList<ArrayList<Object>> pp21Level = panelCount( autoLocusOrder, pp21LocusCount, totalCount );
        ArrayList<ArrayList<Object>> y41Level = panelCount( param.locusOrder.get( "Y41" ), y41LocusCount, maleCount );
        ArrayList<ArrayList<Object>> y41Level_YSUP = panelCount( param.locusOrder.get( "Y41_YSUP" ), y41_YSUPLocusCount, maleCount );
        ArrayList<ArrayList<Object>> y41Level_BGI = panelCount( param.locusOrder.get( "BGI_Y" ), BGILocusCount, maleCount );
        ExcelUtils.writeData(wb, "一代位点输出统计", "", 2, 6, y41Level);
        ExcelUtils.writeData(wb, "一代位点输出统计", "", 2, 10, y41Level_YSUP);
        ExcelUtils.writeData(wb, "一代位点输出统计", "", 2, 14, y41Level_BGI);
        ExcelUtils.writeData(wb, "一代位点输出统计", "", 2, 18, pp21Level);
        ExcelUtils.writeData(wb, "一代位点输出统计", "", 2, 22, all_y);
        ExcelUtils.writeData(wb, "一代位点输出统计", "", 2, 26, all_auto);


        ExcelUtils.writeData(wb, "一代位点输出统计", "sampleTypedCount", 2, 0, allSampleTyped);


    }

    private static void genoType(String project, HashMap<String, SampleInfo> samples, XSSFWorkbook wb) {
        ArrayList<Object> header = new ArrayList<>();
        header.add("sampleName");
        header.add("lane");
        header.add("index");
        header.add("tablet");
        header.add("well");
        header.add("MR36A_LT");
        header.add("BGI-Y_LT");
        header.addAll(param.StrLocusOrder);
        header.addAll(param.SnpLocusOrder);
        ArrayList<ArrayList<Object>> data = new ArrayList<>();
        data.add(header);
        for(SampleInfo sampleInfo:samples.values()) {

            if (! project.equals( sampleInfo.getBasicInfo().getProject() )) {
                continue;
            }
//            if (! sampleInfo.getCalResult().isQualityPass()) {
//                continue;
//            }
//            if(sampleInfo.getCalResult().getPP21Count() < getAutoByChip(sampleInfo.getBasicInfo().chip)){
//                continue;
//            }
//            if (null != sampleInfo.getBasicInfo().getType() && testIsControl( sampleInfo )) {
//                continue;
//            }
            ArrayList<Object> values = new ArrayList<>();
            values.add( sampleInfo.getBasicInfo().name );
            values.add( sampleInfo.getBasicInfo().lane );
            values.add( sampleInfo.getBasicInfo().id );
            values.add( sampleInfo.getBasicInfo().tablet );
            values.add( sampleInfo.getBasicInfo().well );
            values.add( sampleInfo.getCalResult().strAvg<200?0:sampleInfo.getCalResult().getPP21Count() );
            values.add( sampleInfo.getCalResult().getY41Count() );
            for (String locus : param.StrLocusOrder) {
                values.add( sampleInfo.getStrLocusInfo().getOrDefault( locus, new StrLocusInfo() ).getAlleleNameAsString(true,false) );
            }
            data.add(values);
        }
        ExcelUtils.writeData(wb,"分型结果","",0,0,data);
    }


    private static void genoDepth(String project, HashMap<String, SampleInfo> samples, XSSFWorkbook wb){
        ArrayList<Object> header = new ArrayList<>();
        header.add("sampleName");
        header.add("lane");
        header.add("tablet");
        header.addAll(param.StrLocusOrder);
        header.addAll(param.SnpLocusOrder);
        ArrayList<ArrayList<Object>> data = new ArrayList<>();
        data.add(header);
        for(SampleInfo sampleInfo:samples.values()) {
            if (!project.equals(sampleInfo.getBasicInfo().getProject())) {
                continue;
            }
            if (!sampleInfo.getCalResult().isQualityPass()
//                    && sampleInfo.getCalResult().strAvg<30
            ) {
                continue;
            }
            if (null != sampleInfo.getBasicInfo().getType() && testIsControl(sampleInfo)) {
                continue;
            }
            ArrayList<Object> values = new ArrayList<>();
            values.add(sampleInfo.getBasicInfo().name);
            values.add(sampleInfo.getBasicInfo().lane);
            values.add(sampleInfo.getBasicInfo().tablet);
            for (String locus:param.StrLocusOrder){
                values.add(sampleInfo.getStrLocusInfo().getOrDefault(locus, new StrLocusInfo()).getTotalDepth());
            }
            data.add(values);
        }
        ExcelUtils.writeData(wb,"分型深度","",0,0,data);
    }
}