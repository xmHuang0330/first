package fayi.config.Enum;

import lombok.AllArgsConstructor;

/*
    参考序列
 */
@AllArgsConstructor
public enum Reference {
    hg38("HG38");
    public String name;
}
