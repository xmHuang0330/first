package fayi.tableObject;

import fayi.config.Enum.ACLevel;
import fayi.config.Enum.EmptyReason;
import fayi.config.Enum.QC;
import fayi.xml.Objects.GenoType;
import fayi.xml.Objects.LocusData;
import fayi.xml.Objects.QCWithLevel;
import lombok.Data;

import java.util.ArrayList;
import java.util.stream.Collectors;

@Data
public class SnpLocusInfo implements LocusInfoImpl<SnpInfo>{
    //位点名
    private String LocusName;
    //位点qc
    private ArrayList<QC> QualityControl = new ArrayList<>();
    //总深度
    private Integer ForwardTotal = 0;
    private Integer ReverseTotal = 0;
    // 等位基因
    private ArrayList<SnpInfo> Allele = new ArrayList<>();
    private ArrayList<Double> IBObserving = new ArrayList<>();
    private ACLevel acLevel = ACLevel.Low;
    private int AlleleCount;
    private EmptyReason emptyReason;

    public SnpLocusInfo(String locus) {
        this.LocusName = locus;
    }

    public SnpLocusInfo(LocusData locusData){
        LocusName = locusData.getLocusName();
        for (QCWithLevel qcWithLevel : locusData.getQualityControl()) {
            for (QC qc : QC.values()) {
                if (qcWithLevel.getName().equals(qc.Name)) {
                    QualityControl.add(qc);
                }
            }
        }
        setIBObserving(locusData.getIbo());
        //
        ForwardTotal = locusData.getTotalDepth();
    }
    
    public void setForwardTotal(Integer forwardTotal) {
        ForwardTotal += forwardTotal;
    }

    public void setReverseTotal(Integer reverseTotal) {
        ReverseTotal += reverseTotal;
    }

    public Integer getTotalDepth() {
        return ForwardTotal + ReverseTotal;
    }

    //获取qc
    public ArrayList<QCWithLevel> getQCWithLevel() {
        ArrayList<QCWithLevel> values = new ArrayList<>();
        for (QC qc : QualityControl) {
            if (QC.Allele_count.equals(qc)) {
                values.add(new QCWithLevel(qc.Name, acLevel.getShortName()));
            } else {
                values.add(new QCWithLevel(qc.Name));
            }
        }
        return values;
    }

    public String getQCAsString() {
        StringBuilder qcString = new StringBuilder();
        for (QC qc : QualityControl) {
            qcString.append(",").append(qc.Name);
        }
        return qcString.toString().replaceFirst(",", "");
    }


    //获取等位基因型，得到以逗号分隔的字符串
    public String getSnpAlleleAsString(Boolean mergeSameAlleleName) {
        if (mergeSameAlleleName) {
            return Allele.stream().map(SeqInfo::getAlleleName).collect(Collectors.joining(","));
        } else {
            return Allele.stream().map(SeqInfo::getAlleleName).distinct().collect(Collectors.joining(","));
        }
    }

    public ArrayList<GenoType> getSnpAlleleAsGenoTypes(){
        ArrayList<GenoType> genotypes = new ArrayList<>();
        for(SnpInfo snpInfo:Allele){
            genotypes.add(new GenoType("",snpInfo.AlleleName));
        }
        return genotypes;
    }


}
