package fayi.tableObject;

import java.util.ArrayList;

public interface LocusInfoImpl<T> {
    ArrayList<SeqInfo> Allele = new ArrayList<>();

}
