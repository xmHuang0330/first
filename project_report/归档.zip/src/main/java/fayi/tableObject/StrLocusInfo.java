package fayi.tableObject;

import fayi.config.Enum.ACLevel;
import fayi.config.Enum.EmptyReason;
import fayi.config.Enum.QC;
import fayi.xml.Objects.GenoType;
import fayi.xml.Objects.LocusData;
import fayi.xml.Objects.QCWithLevel;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.stream.Collectors;

/*
 * 位点信息
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class StrLocusInfo implements LocusInfoImpl<StrInfo> {
    //位点名
    private String LocusName = "";
    //位点qc
    private ArrayList<QC> QualityControl = new ArrayList<>();
    //总深度
    private Integer ForwardTotal = 0;
    private Integer ReverseTotal = 0;
    // 等位基因
    private ArrayList<StrInfo> Allele = new ArrayList<>();
    private ArrayList<Double> IBObserving = new ArrayList<>();
    private ACLevel acLevel = ACLevel.Low;
    private int AlleleCount;
    private EmptyReason emptyReason;

    public StrLocusInfo(String locusName) {
        LocusName = locusName;
    }

    public StrLocusInfo(LocusData locusData){
        LocusName = locusData.getLocusName();
        for (QCWithLevel qcWithLevel : locusData.getQualityControl()) {
            for (QC qc : QC.values()) {
                if (qcWithLevel.getName().equals(qc.Name)) {
                    QualityControl.add(qc);
                }
            }
        }
        setIBObserving(locusData.getIbo());
        //
        ForwardTotal = locusData.getTotalDepth();
    }

    public StrLocusInfo(String locusName, ArrayList<QC> qualityControl, Integer forwardTotal, Integer reverseTotal, ArrayList<StrInfo> allele, ArrayList<Double> IBObserving) {
        LocusName = locusName;
        QualityControl = qualityControl;
        ForwardTotal = forwardTotal;
        ReverseTotal = reverseTotal;
        Allele = allele;
        this.IBObserving = IBObserving;
    }

    public StrLocusInfo(String locusName, Integer forwardTotal, Integer reverseTotal) {
        LocusName = locusName;
        ForwardTotal = forwardTotal;
        ReverseTotal = reverseTotal;
    }

    //深度累加
    public void setForwardTotal(Integer depth) {
        ForwardTotal += depth;
    }
    public void setReverseTotal(Integer depth){
        ReverseTotal += depth;
    }

    public Integer getTotalDepth() {
        return ForwardTotal + ReverseTotal;
    }

    //获取等位基因型，得到以逗号分隔的字符串
    public String getAlleleNameAsString(Boolean mergeSameAlleleName,Boolean useAlias) {

//        if(Allele.size() < 1){
//            return emptyReason==null?"":emptyReason.name();
//        }
        Allele.sort( Comparator.comparing( o -> Float.parseFloat( "X".equals( o.AlleleName ) ? "0" : "Y".equals( o.AlleleName ) ? "1" : o.AlleleName ) ) );
        if (mergeSameAlleleName) {
            if (useAlias && (LocusName.equals( "SRY" ) || "Y-indel".equals( LocusName ))) {
                return Allele.size() > 0 ? "Y" : "";
            } else {
                return Allele.stream().map( useAlias ? SeqInfo::getExcelName : SeqInfo::getAlleleName ).distinct().collect( Collectors.joining( "," ) );
            }
        } else {
            if (useAlias && (LocusName.equals( "SRY" ) || "Y-indel".equals( LocusName ))) {
                return Allele.size() > 0 ? "Y" : "";
            } else {
                return Allele.stream().map(useAlias ? SeqInfo::getExcelName : SeqInfo::getAlleleName).collect(Collectors.joining(","));
            }
        }
    }


    //获取等位基因型
    public ArrayList<String> getAlleleNameAsStringList() {
        ArrayList<String> alleleString = new ArrayList<>();
        Allele.sort(Comparator.comparing(SeqInfo::getReads).reversed());
        for (SeqInfo si : Allele) {
            alleleString.add(si.getAlleleName());
        }

        return alleleString;
    }

    //获取qc
    public ArrayList<QCWithLevel> getQCWithLevel() {
        ArrayList<QCWithLevel> values = new ArrayList<>();
        for (QC qc : QualityControl) {
            if (QC.Allele_count.equals(qc)) {
                values.add(new QCWithLevel(qc.Name, acLevel.getShortName()));
            } else {
                values.add(new QCWithLevel(qc.Name));
            }
        }
        return values;
    }

    public String getQCAsString() {
        StringBuilder qcString = new StringBuilder();
        for (QC qc : QualityControl) {
            qcString.append(",").append(qc.Name);
        }
        return qcString.toString().replaceFirst(",", "");
    }

    //获取qc简称，以字符串形式，无间隔
    public String getQCAsIndictor() {
        StringBuilder IndictorString = new StringBuilder();
        for (QC qc: QualityControl) {
            IndictorString.append(qc.Indictor);
        }
        return IndictorString.toString();
    }

    @Override
    public String toString() {
        String result = "";
        for (SeqInfo strInfo : Allele) {
            result += String.format( "%s\t%s\t%s\t%s\n", strInfo.Locus, strInfo.AlleleName, strInfo.Reverse + strInfo.getForward(), strInfo.RepeatSequence );
        }
        return result;
    }

    public double getTypedDepth() {
        double typedDepth = 0d;
        for (StrInfo strInfo : Allele) {
            for (StrInfo ngsStutter : strInfo.getNGSStutter()) {
                typedDepth += ngsStutter.getReads();
            }
            typedDepth += strInfo.getReads();
        }
        return typedDepth;
    }

    public ArrayList<GenoType> getAlleleNameAsGenoType() {
        ArrayList<GenoType> genotypes = new ArrayList<>();
        for(StrInfo strInfo:Allele){
            genotypes.add(new GenoType(strInfo.formatSnpAsString(),strInfo.AlleleName));
        }
        return genotypes;
    }

    public String getSequenceAsString() {
        return Allele.stream().map(SeqInfo::getRepeatSequence).collect(Collectors.joining(","));
    }
}
