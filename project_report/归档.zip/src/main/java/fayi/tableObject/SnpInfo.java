package fayi.tableObject;

import fayi.xml.Objects.Reads;
import fayi.xml.Objects.Site;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.util.ArrayList;

/*
    snp序列信息
 */
@Data
@EqualsAndHashCode(callSuper = true)
public class SnpInfo extends SeqInfo {

    public SnpInfo setAboveAT(boolean aboveAT) {
        this.aboveAT = aboveAT;
        return this;
    }

    public SnpInfo(String Locus, String AlleleName, Boolean Typed, Integer Bases, String RepeatSequence, int Forward, int Reverse) {
        super(Locus, AlleleName, Typed, Bases, RepeatSequence, Forward, Reverse);
    }

    //xml的site对象转换为snpinfo
    public SnpInfo(Site site) {
        super(site.Locus, site.Genotype, "Yes".equals(site.Typed), site.Bases, site.RepeatSequence, (int) site.Reads.forward, (int) site.Reads.reverse);
    }

    //格式化输出为report excel 中的 detail information
    public ArrayList<Object> FormatAsList(float meanDepth) {
        ArrayList<Object> objects = new ArrayList<>();
        objects.add(Locus);
        objects.add(AlleleName);
        objects.add(Typed);
        objects.add((Forward+Reverse) / meanDepth < 0.015?0:Forward+Reverse);
        return objects;
    }
    //转换为xml文件对象
    public Site formatAsSite(){
        return new Site(Locus,Bases,AlleleName, Typed ?"Yes":"No", new Reads(Forward,Reverse,Forward+Reverse),"" );
    }

}
